package com.example.banksystem.backend;

import com.example.banksystem.controller.BankInfoController;
import com.example.banksystem.dao.BankInfoDao;
import com.example.banksystem.dao.Dao;
import com.example.banksystem.model.BankInfo;

import java.util.Optional;

public class Servise {

    private static Dao<BankInfo> bankInfoDao;

    public static double creditsum(int sum,int term){

        bankInfoDao = new BankInfoDao();

        Optional<BankInfo> bankInfoOptional = bankInfoDao.get(Long.parseLong(BankInfoController.chenge));           // <=== Замість 1 номер банку ща MYSQL
        BankInfo bankInfo = bankInfoOptional.get();

        // bankInfo.getPercent()        <===== повертає проценти банка

        double creditsum = sum+(bankInfo.getPercent()*sum*term)/12/100 ;
        return creditsum;
    }
    public static double rescreditsum(int sum,double creditsume){
        double rescredit = creditsume - sum;
        return rescredit;
    }
    public static double mounspay(double creditsum){
        double mounspay = creditsum/12;
        return mounspay;
   }
}
