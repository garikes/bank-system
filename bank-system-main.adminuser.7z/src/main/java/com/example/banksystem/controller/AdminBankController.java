package com.example.banksystem.controller;

import com.example.banksystem.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminBankController {
    @FXML
    private Button bunkbutton;

    @FXML
    private Button editbutton;

    @FXML
    private Button userbutton;

    @FXML
    private Button viewbutton;

    @FXML
    private Button logoutbutton;


    public void userButtonOnAction(ActionEvent event) {
        Stage stage = (Stage) userbutton.getScene().getWindow();
        stage.close();

        try {
            Parent root = FXMLLoader.load(Application.class.getResource("view/adminuser.fxml"));
            Stage mainStage = new Stage();
            Scene scene = new Scene(root, 790, 446);
            scene.getStylesheets().add(Application.class.getResource("css/style.css").toExternalForm());
            mainStage.setScene(scene);
            mainStage.show();

        } catch (IOException e) {
            e.printStackTrace();
            e.getCause();
        }
    }
    public void logoutButtonOnAction(ActionEvent event) {
        Stage stage = (Stage) logoutbutton.getScene().getWindow();
        stage.close();

        try {
            Parent root = FXMLLoader.load(Application.class.getResource("view/login.fxml"));
            Stage mainStage = new Stage();
            Scene scene = new Scene(root, 779, 520);
            scene.getStylesheets().add(Application.class.getResource("css/style.css").toExternalForm());
            mainStage.setScene(scene);
            mainStage.show();

        } catch (IOException e) {
            e.printStackTrace();
            e.getCause();
        }
    }
}
